import Csound.Patch
import Csound.Base

main = dac $ sum [mix $ atSco razorLeadFast $ mel [temp (0.5, cpspch 8.10)] , mix $ atSco razorLead $ mel [temp (0.4, cpspch 8.05)]]
                  