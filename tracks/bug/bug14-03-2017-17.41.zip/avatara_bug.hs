
import Csound.Patch
import Csound.Base

pace = 40
avatar = 
   let oct = 8
       ins pch = temp (0.1, cpspch $ oct + pch)
       in mix $ atSco (avatara 20) $ mel $ map ins [0.05]
     
synth = 
   let oct = 8
       ins pch = temp (0.5, cpspch $ oct + pch)
       in mix $ atSco razorLeadFast $ mel $ map ins [0.10]
                                 
canon = 
   let oct = 8
       ins pch = temp (0.4, cpspch $ oct + pch)
       tick n = 60 * 16 / 96 * n / pace
       in mix $ atSco razorLead
                           $ mel $ map ins [0.05,1.00,0.10,0.08,0.07
                                             ,0.05,0.07,0.08,0.07,0.05,0.04
                                             ,0.05,1.00
                                             ,0.05,0.08,0.07,0.05,1.01
                                             ,0.10,0.08,0.07,0.05,0.07,0.08,0.10,1.00]

pad =                                                    
   let oct = 7
       ins pch = temp (0.3, cpspch $ oct + pch)
       tick n = 60 * 16 / 16 * n / pace
       in mix $ atSco polySynth
                   $ har [ mel $ zipWith str (map tick [1,1,2]) 
                                       $ map ins 
                              [ 0.10,1.03,1.05]
                                 , mel $ zipWith str (map tick [2,2,2])
                                  $ map ins 
                                 [1.10,1.08,1.07]]

main = dac $ sum $ [ atMidi polySynth
                   ,return avatar
                   ,return synth
                   ,return canon
                   ,return pad
                   ]


                  